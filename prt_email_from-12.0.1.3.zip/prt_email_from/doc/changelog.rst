`12.0.1.3`
------------

- **FIX:** Important fix. Please update!

`12.0.1.0`
----------

- Release for Odoo 11
