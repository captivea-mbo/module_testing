# Email address tweaks

Use company email address for outgoing email messages (Some User <some.user@example.com> / Some User <mycompany@example.com>)
Add company name to sender's name in 'From' (Some User <mycompany@example.com> / Some User via My Company <mycompany@example.com>)
Add sender's name to company name in 'Reply-to' (My Company <mycompany@example.com> / Some User via My Company <mycompany@example.com>)
Set names joint for 'From' and 'Reply-to' (Some User My Company <mycompany@example.com> / Some User via My Company <mycompany@example.com>)

